package com.test.boiler;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivityOn extends AppCompatActivity {

    private TextView tv_temp_on;
    Button btn_menu_on;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_on);

        tv_temp_on = findViewById(R.id.tv_temp_on);
        btn_menu_on = findViewById(R.id.btn_menu_on);

        Intent intent = getIntent();


        btn_menu_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivityOn.this, SubActivityOn.class);
                startActivity(intent);
            }
        });



    }
}