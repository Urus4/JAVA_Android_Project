package com.test.boiler;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;


public class SubActivityOn extends AppCompatActivity {


    Button btn_back_on;
    Button btn_on_on;
    Button btn_off_on;

    static List<Status> data;

    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_on);


        btn_back_on = findViewById(R.id.btn_back_on);
        btn_on_on = findViewById(R.id.btn_on_on);
        btn_off_on = findViewById(R.id.btn_off_on);

        //======================================================================================
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                String page = "http://10.10.141.56:8080/android/statusList";

                try {
                    URL url = new URL(page);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    StringBuilder stringBuilder = new StringBuilder();

                    if(conn != null){

                        conn.setConnectTimeout(10000);
                        conn.setRequestMethod("GET");
                        conn.setUseCaches(false);
                        if(conn.getResponseCode() == HttpURLConnection.HTTP_OK){

                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));

                            while(true){
                                String line = bufferedReader.readLine();
                                if(line == null) break;
                                stringBuilder.append(line + "\n");
                            }
                            bufferedReader.close();
                        }
                        conn.disconnect();
                    }

                    Gson gson = new Gson();

                    Type type = new TypeToken<List<Status>>() {}.getType();
                    data = gson.fromJson(String.valueOf(stringBuilder),type);


                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } //End of run()
        }); //End of Thread
        thread.start();
        //======================================================================================


        Intent intent = getIntent();

        btn_back_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(SubActivityOn.this, MainActivityOn.class);
                startActivity(intent);

            }
        });


        btn_on_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(SubActivityOn.this, MainActivityOn.class);
                startActivity(intent);
            }
        });

        btn_off_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(SubActivityOn.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}
