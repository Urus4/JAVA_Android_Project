package com.test.boiler_demo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tv_status;
    private TextView tv_temp;
    Button btn_menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_status = findViewById(R.id.tv_status);
        tv_temp = findViewById(R.id.tv_temp);
        btn_menu = findViewById(R.id.btn_menu);
        Intent intent = getIntent();

        //======================================================================================

        String name = intent.getStringExtra("text1");
        System.out.println("name = " + name);
        tv_status.setText(name);

        int temp = intent.getIntExtra("text2", 0);
        tv_temp.setText(temp);

        //======================================================================================

        btn_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SubActivity.class);
                startActivity(intent);
            }
        });

    }
}