package com.test.boiler_demo;

public class Status {

    private String status;
    private int temperature;
    public String getStatus(){
        return status;
    }
    public int getTemperature(){
        return temperature;
    }

}