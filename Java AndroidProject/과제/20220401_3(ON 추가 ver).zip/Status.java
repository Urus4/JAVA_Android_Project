package com.test.boiler;

public class Status {

    private String status;
    private int temperature;
    public String getStatus(){
        return status;
    }
    public int getTemperature(){
        return temperature;
    }

}