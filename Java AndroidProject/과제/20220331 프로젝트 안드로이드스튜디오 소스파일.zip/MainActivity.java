package com.test.boiler;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView tv_json;
    private RecyclerView recyclerView;
    //private BoardAdapter boardAdapter;

    static List<Status> data;

    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_json = findViewById(R.id.tv_json);
        //recyclerView = findViewById(R.id.recyclerView);

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                String page = "http://10.10.141.56:8080/android/statusList";

                try {
                    URL url = new URL(page);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    StringBuilder stringBuilder = new StringBuilder();

                    if(conn != null){

                        conn.setConnectTimeout(10000);
                        conn.setRequestMethod("GET");
                        conn.setUseCaches(false);
                        if(conn.getResponseCode() == HttpURLConnection.HTTP_OK){

                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));

                            while(true){
                                String line = bufferedReader.readLine();
                                if(line == null) break;
                                stringBuilder.append(line + "\n");
                            }
                            bufferedReader.close();
                        }
                        conn.disconnect();
                    }

                    tv_println("서버에서 받아온 JSON 타입의 String : " + "\n" + String.valueOf(stringBuilder));

                    tv_println("JSON Parsing 결과값");
                    Gson gson = new Gson();

                    Type type = new TypeToken<List<Status>>() {}.getType();
                    data = gson.fromJson(String.valueOf(stringBuilder),type);

                    String statusON = data.get(0).getStatus();
                    int temperatureHigh = data.get(0).getTemperature();

                    String statusOFF = data.get(1).getStatus();
                    int temperatureLow = data.get(1).getTemperature();

                    tv_println("상태 : " + statusOFF + ", 온도 : " + temperatureLow);
                    tv_println("상태 : " + statusON + ", 온도 : " + temperatureHigh);
                    //tv_println("\nRecyclerView로 구현");


                    //rv_println(String.valueOf(stringBuilder));

                    //boardAdapter = new BoardAdapter(data);
                    //recyclerView.setAdapter(boardAdapter);
                    //recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            } //End of run()

        }); //End of Thread
        thread.start();

    }
    public void tv_println(final String data){
        handler.post(new Runnable() {
            @Override
            public void run() {
                tv_json.append(data + "\n");
            }
        });
    }

}